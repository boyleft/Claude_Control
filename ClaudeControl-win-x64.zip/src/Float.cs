using System;
using System.Collections.Generic;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Threading;
using Drawing = System.Drawing;
using Forms = System.Windows.Forms;
using Shapes = System.Windows.Shapes;

namespace ClaudeControl
{
    internal sealed class FloatingControl
    {
        internal readonly Window Badge = Surface(180, 148, "应用悬浮标");
        internal readonly Window Flyout;
        private readonly Dictionary<DesktopApp,Button> buttons=new Dictionary<DesktopApp,Button>();
        private readonly Shapes.Ellipse lamp = new Shapes.Ellipse { Width=7, Height=7, Margin=new Thickness(5,1,0,0) };
        private readonly DispatcherTimer hover = new DispatcherTimer { Interval=TimeSpan.FromMilliseconds(220) };
        private readonly Action<int,int> save;
        private readonly Border tile;
        private readonly TextBlock clock = new TextBlock { FontSize=25, FontWeight=FontWeights.SemiBold, TextAlignment=TextAlignment.Center };
        private readonly TextBlock clockDate = new TextBlock { FontSize=12, TextAlignment=TextAlignment.Center };
        private Drawing.Point anchor;
        private Drawing.Rectangle origin;
        private bool pressed;
        private bool enabled;
        internal static Brush Color(string value) { return (Brush)new BrushConverter().ConvertFromString(value); }
        private static Window Surface(double width,double height,string title)
        {
            return new Window { Title=title, Width=width, Height=height, WindowStyle=WindowStyle.None,
                AllowsTransparency=true, Background=Brushes.Transparent, Topmost=true, ShowInTaskbar=false,
                ResizeMode=ResizeMode.NoResize, ShowActivated=false, WindowStartupLocation=WindowStartupLocation.Manual,
                FontFamily=new FontFamily("Microsoft YaHei UI, Segoe UI") };
        }
        internal FloatingControl(Style action, KeyValuePair<DesktopApp,string>[] choices, Action<DesktopApp> closeApp,
            Action showWindow, Action<int,int> savePosition)
        {
            save = savePosition;
            var content = new StackPanel();
            var glyph = new Grid { Width=16, Height=16, Margin=new Thickness(0,0,6,0) };
            glyph.Children.Add(new Shapes.Ellipse { Stroke=Color("#28361F"), StrokeThickness=2 });
            glyph.Children.Add(new Shapes.Rectangle { Width=5, Height=5, RadiusX=1, RadiusY=1, Fill=Color("#1B2614") });
            var label = new StackPanel { Orientation=Orientation.Horizontal, HorizontalAlignment=HorizontalAlignment.Center, Margin=new Thickness(0,0,0,6) };
            label.Children.Add(glyph);
            label.Children.Add(new TextBlock { Text="应用控制", Foreground=Color("#141C10"), FontSize=12, FontWeight=FontWeights.SemiBold });
            label.Children.Add(lamp);
            content.Children.Add(label);
            content.Children.Add(clock);
            content.Children.Add(clockDate);
            foreach(var text in new[]{clock,clockDate}) text.Foreground=Color("#141C10");
            tile = new Border { Width=180, Padding=new Thickness(12), Child=content, Background=Color("#788C5D"), CornerRadius=new CornerRadius(20),
                BorderBrush=Color("#5B6D46"), BorderThickness=new Thickness(1), Cursor=Cursors.SizeAll };
            Badge.Content=new Viewbox { Child=tile };
            Badge.SourceInitialized += delegate { ResizeBadge(); };
            Flyout=Surface(152,52*choices.Length,"应用快捷操作");
            var actions=new System.Windows.Controls.Primitives.UniformGrid { Rows=choices.Length, Columns=1, Background=Brushes.Transparent };
            foreach (var choice in choices) {
                var app=choice.Key;
                var button=new Button { Style=action, Content=choice.Value, Padding=new Thickness(8,0,8,0),
                    Margin=new Thickness(1,1,1,actions.Children.Count==choices.Length-1 ? 0 : 1) };
                AutomationProperties.SetName(button,choice.Value);
                button.Click+=delegate { closeApp(app); };
                buttons.Add(app,button);
                actions.Children.Add(button);
            }
            Flyout.Content=actions;
            Badge.MouseEnter += delegate { if (!pressed) OpenFlyout(); };
            Badge.MouseLeave += delegate { hover.Start(); };
            Flyout.MouseEnter += delegate { hover.Stop(); };
            Flyout.MouseLeave += delegate { hover.Start(); };
            hover.Tick += delegate {
                hover.Stop();
                if (!Badge.IsMouseOver && !Flyout.IsMouseOver) Flyout.Hide();
            };
            bool dragged=false, doubleClick=false;
            Badge.MouseLeftButtonDown += delegate(object sender, MouseButtonEventArgs e) {
                doubleClick=e.ClickCount==2 && !dragged;
                dragged=false;
                pressed=true; anchor=Forms.Cursor.Position; origin=Bounds(Badge);
                Flyout.Hide(); Badge.CaptureMouse(); e.Handled=true;
            };
            Badge.MouseMove += delegate {
                if (!pressed) return;
                var p=Forms.Cursor.Position;
                var threshold=Forms.SystemInformation.DragSize;
                if (!dragged && Math.Abs(p.X-anchor.X)*2<threshold.Width && Math.Abs(p.Y-anchor.Y)*2<threshold.Height) return;
                dragged=true;
                Move(Badge, origin.X+p.X-anchor.X, origin.Y+p.Y-anchor.Y, Forms.Screen.FromPoint(p).WorkingArea);
            };
            Badge.MouseLeftButtonUp += delegate {
                if (!pressed) return;
                bool open=doubleClick && !dragged;
                Badge.ReleaseMouseCapture();
                if (open) showWindow();
            };
            Badge.LostMouseCapture += delegate {
                if (!pressed) return;
                pressed=false;
                if (dragged) { var bounds=Bounds(Badge); save(bounds.X,bounds.Y); }
                if (Badge.IsMouseOver) OpenFlyout();
            };
        }
        internal void UpdateClock(DateTimeOffset time)
        {
            clock.Text=time.ToString("HH:mm:ss",CultureInfo.InvariantCulture);
            clockDate.Text=time.ToString("yyyy-MM-dd",CultureInfo.InvariantCulture);
        }
        private void ResizeBadge()
        {
            var source=PresentationSource.FromVisual(Badge);
            if (source==null) return;
            var previous=Bounds(Badge);
            tile.Measure(new Size(Double.PositiveInfinity,Double.PositiveInfinity));
            var scale=source.CompositionTarget.TransformToDevice;
            int width=(int)Math.Ceiling(tile.DesiredSize.Width), height=(int)Math.Ceiling(tile.DesiredSize.Height);
            Badge.Width=width/scale.M11; Badge.Height=height/scale.M22;
            Badge.UpdateLayout();
            if (Badge.IsVisible) {
                Move(Badge,previous.X,previous.Bottom-height,Forms.Screen.FromRectangle(previous).WorkingArea);
                if (Flyout!=null && Flyout.IsVisible) OpenFlyout();
            }
        }
        internal void SetVisible(bool value, int? x, int? y)
        {
            enabled=value;
            if (!value) { hover.Stop(); Flyout.Hide(); Badge.Hide(); return; }
            // Ensure the HWND exists before positioning it in physical monitor coordinates.
            Badge.Show();
            var area=Forms.Screen.PrimaryScreen.WorkingArea;
            if (x.HasValue && y.HasValue) area=Forms.Screen.FromPoint(new Drawing.Point(x.Value,y.Value)).WorkingArea;
            var size=Bounds(Badge);
            Move(Badge, x ?? area.Right-size.Width-22, y ?? area.Top+80, area);
            if (Badge.IsMouseOver) OpenFlyout();
        }
        private void OpenFlyout()
        {
            if (!enabled || pressed) return;
            hover.Stop();
            var b=Bounds(Badge);
            var area=Forms.Screen.FromRectangle(b).WorkingArea;
            double scaleY=PresentationSource.FromVisual(Badge).CompositionTarget.TransformToDevice.M22;
            // At the top of the work area, fit all rows above the same bottom edge.
            Flyout.Height=Math.Min(52*buttons.Count,(b.Bottom-area.Top)/scaleY);
            foreach (var button in buttons.Values) button.FontSize=Math.Min(15,(Flyout.Height/buttons.Count-2)*0.68);
            Flyout.Show();
            Flyout.UpdateLayout();
            var f=Bounds(Flyout);
            int x=b.Right+3+f.Width<=area.Right ? b.Right+3 : b.Left-f.Width-3;
            Move(Flyout, x, b.Bottom-f.Height, area);
        }
        internal void Update(DesktopApp? stopping, bool running)
        {
            foreach (var pair in buttons) {
                pair.Value.IsEnabled=!stopping.HasValue;
                pair.Value.Content=stopping==pair.Key ? "正在关闭…" : AutomationProperties.GetName(pair.Value);
            }
            lamp.Fill=Color(running ? "#24331A" : "#DCE5D1");
        }
        internal void Dispose()
        {
            enabled=false; hover.Stop(); Flyout.Close(); Badge.Close();
        }
        [StructLayout(LayoutKind.Sequential)] private struct Rect { internal int Left, Top, Right, Bottom; }
        [DllImport("user32")] private static extern bool GetWindowRect(IntPtr hwnd, out Rect rect);
        [DllImport("user32")] private static extern bool SetWindowPos(IntPtr hwnd, IntPtr after, int x, int y,int w,int h,uint flags);
        private static Drawing.Rectangle Bounds(Window w)
        {
            Rect r; GetWindowRect(new WindowInteropHelper(w).Handle, out r);
            return Drawing.Rectangle.FromLTRB(r.Left,r.Top,r.Right,r.Bottom);
        }
        private static void Move(Window w, int x, int y, Drawing.Rectangle area)
        {
            var b=Bounds(w);
            x=Math.Max(area.Left,Math.Min(x,area.Right-b.Width));
            y=Math.Max(area.Top,Math.Min(y,area.Bottom-b.Height));
            SetWindowPos(new WindowInteropHelper(w).Handle, IntPtr.Zero, x,y,0,0,0x15);
        }
    }
}
